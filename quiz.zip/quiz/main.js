//need to initialize variables
//all answers options
const option1 = document.querySelector('.option1'),
        option2 = document.querySelector('.option2'),
        option3 = document.querySelector('.option3'),
        option4 = document.querySelector('.option4');

//all our options

const optionElements = document.querySelectorAll('.option');
//question variable
const question=document.getElementById('question');//the question
const numberOfQuestion=document.getElementById('number-of-question'),
        numberOfAllQuestions = document.getElementById('number-of-all-questions');

let indexOfQuestion,//index of a current question
    indexOfPage=0;//index of a page

const answersTracker=document.getElementById('answers-tracker');//obertka dlja tracker

const btnNext=document.getElementById('btn-next');//the further button

let score=0;//itogovij rezult viktorini

const correctAnswer =document.getElementById('correct-answer'), //the quantity of correct answers
        numberOfAllQuestions2=document.getElementById('number-of-all-questions-2');// the question of all the questions
        btnTryAgain=document.getElementById('btn-try-again');//to start the quiz again

const questions = [
{
    question: 'Сколько будет: 2+2*2',
    options: [
                '8',
                '6',
                '10',
                '0',
],
    rightanswer: 1

},
{
    question: 'Сколько слогов в слове "Мариуполь"',
    options: [
                '3',
                '2',
                '4',
                '5',
],
    rightanswer: 2

},
{
    question: 'Если 2+2=4, то 4*2=: ?',
    options: [
                '6',
                '8',
                '10',
                '12',
    ],
    rightanswer: 1

    },
];

numberOfAllQuestions.innerHTML=questions.Length;//vivodim kol-vo voprosov

const load=()=>{ //this function will be loaded only when the full page would be loaded
    question.innerHTML=questions[indexOfQuestion].question; //to to the property innerHTML, where in the array questions is the question

    //write the answers
    option1.innerHTML = questions[indexOfQuestion].options[0];
    option2.innerHTML = questions[indexOfQuestion].options[1];
    option3.innerHTML = questions[indexOfQuestion].options[2];
    option4.innerHTML = questions[indexOfQuestion].options[3];

    //create the number of current page
    numberOfQuestion.innerHTML=indexOfPage+1;
    indexOfPage++;//the increase of index of the page
};

let completeAnswers=[]//the array for already asked questions

const randomQuestion =()=>{//function which generate the random questions

//object Math
let randomNumber= Math.floor(Math.random()*questions.length);
let hitDuplicate = false;// jakorj for checking the similar questions

if(indexOfPage == questions.length) {
quizOver()

}else {
if(completeAnswers.length > 0){

    completeAnswers.forEach(item=>{
        if(item == randomNumber){
            hitDuplicate = true;
        }
    });
    if (hitDuplicate){
        randomQuestion();
    }else {
        indexOfQuestion = randomNumber;
        load();
    }
}
if(completeAnswers.length == 0){
    indexOfQuestion=randomNumber;
    load();
}

}
completeAnswers.push(indexOfQuestion);//help to fulfill with indexes, which we have created above

};
//function red colour- wrong, green one- correct
const checkAnswer = el => {
if (el.target.dataset.id == questions[indexOfQuestion].rightanswer){
    el.target.classList.add('correct');// in the class 'correct'
    updateAnswerTracker('correct');
    score++;

} else{
    el.target.classList.add('wrong');
    updateAnswerTracker('wrong');

}
disableOptions();

}


//function to check answer in order to where the user clicks
for(option of optionElements){
    option.addEventListener('click', e=> checkAnswer(e));

}

const disableOptions=()=>{
optionElements.forEach(item=>{
    item.classList.add('disabled');
    if(item.dataset.id == questions[indexOfQuestion].rightanswer){
        item.classList.add('correct');
    }
})

}

const enableOptions=()=>{
    optionElements.forEach(item => {
        item.classList.remove('disabled', 'correct', 'wrong'); // delete all the classes from the questions

    })

};
const answerTracker =()=>{
    questions.forEach(() => {
       const div = document.createElement('div');
       answersTracker.appendChild(div); 
    })

};
//function to add the class on every point for the tracker
const updateAnswerTracker = status=>{
    answersTracker.children[indexOfPage-1].classList.add(`${status}`);

}

const validate = () =>{
    if(!optionElements[0].classList.contains('disabled')){
        alert('Please, choose one of answer variant');

    }else{
        randomQuestion();
        enableOptions();
    }

}


const  quizOver=()=>{
    document.querySelector('.quiz-over-modal').classList.add('active');
    correctAnswer.innerHTML=score;
    numberOfAllQuestions2.innerHTML=questions.length;
};

const tryAgain =()=>{
    window.location.reload();

};

btnTryAgain.addEventListener('click', tryAgain);


btnNext.addEventListener('click', ()=> {
    validate();
})

window.addEventListener('load', () =>{
    randomQuestion();
    answerTracker();
}); // to load the function load
























































